opus.Gizmo({
	name: "Acme.controls.control",
	type: "Container",
	w: 200,
	h: 250,
	styles: {
		border: 6
	},
	user: {},
	chrome: [
		{
			name: "window",
			plane: 1,
			caption: "AcmeRox",
			type: "opus.Aerie.Window",
			l: 0,
			w: 196,
			t: 24,
			h: 128,
			styles: {
				zIndex: 0
			}
		},
		{
			name: "title",
			content: "I am Acme, hear me roar.",
			l: 0,
			w: 150,
			t: 0,
			h: 24,
			styles: {
				border: "0"
			}
		}
	]
});