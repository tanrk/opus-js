﻿opus.registry.add({
	name: "Acme control",
	description: "Acme is da best.",
	package: "Acme.controls",
	author: "Acme Limited",
	version: "0.1",
	type: "Acme.controls.control",
	keywords: "acme,control",
	exemplar: {type: "Control", content: "Acme", styles: {oneLine: true, textAlign:"center"},
		width: "100%", height: 22, verticalAlign: "center"}
});